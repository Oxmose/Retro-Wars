export LD_LIBRARY_PATH=lib/tinyxml2-master:lib/tmxparser-master:lib/SFML_LINUX/lib
./RetroWars 5000
