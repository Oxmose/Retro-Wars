export DYLD_LIBRARY_PATH=lib/tinyxml2-master:lib/tmxparser-master:lib/SFML-2.3.2-osx-clang-universal/lib
./Retrowars 5000
