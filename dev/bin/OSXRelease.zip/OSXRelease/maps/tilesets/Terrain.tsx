<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Terrain" tilewidth="16" tileheight="16" tilecount="144">
 <image source="terrain.bmp" trans="000000" width="288" height="128"/>
 <terraintypes>
  <terrain name="Moutain1" tile="90"/>
  <terrain name="Mountain2" tile="126"/>
  <terrain name="Plain" tile="0"/>
  <terrain name="Road1" tile="1"/>
  <terrain name="Road2" tile="19"/>
  <terrain name="Road3" tile="37"/>
  <terrain name="Road4" tile="73"/>
  <terrain name="Road5" tile="91"/>
  <terrain name="Road6" tile="109"/>
  <terrain name="Road7" tile="127"/>
  <terrain name="Road8" tile="128"/>
  <terrain name="Road9" tile="110"/>
  <terrain name="Road10" tile="92"/>
  <terrain name="Road11" tile="74"/>
  <terrain name="Bridge1" tile="20"/>
  <terrain name="Bridge2" tile="2"/>
  <terrain name="Road12" tile="51"/>
  <terrain name="Road13" tile="69"/>
  <terrain name="Woods1" tile="123"/>
  <terrain name="Woods2" tile="54"/>
 </terraintypes>
</tileset>
