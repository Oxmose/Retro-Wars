<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Unit" tilewidth="16" tileheight="16" tilecount="130">
 <image source="unit.bmp" trans="000000" width="208" height="160"/>
 <terraintypes>
  <terrain name="InfantryRed" tile="0"/>
  <terrain name="MdTankRed" tile="1"/>
  <terrain name="ReconRed" tile="2"/>
  <terrain name="ArtilleryRed" tile="3"/>
  <terrain name="NeoTankRed" tile="9"/>
  <terrain name="MegaTankRed" tile="10"/>
  <terrain name="MechRed" tile="13"/>
  <terrain name="TankRed" tile="14"/>
  <terrain name="RocketRed" tile="16"/>
 </terraintypes>
</tileset>
